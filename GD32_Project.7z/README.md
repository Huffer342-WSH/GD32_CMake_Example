### 环境配置

交叉编译器：[gcc-arm-none-eabi-10.3-2021.10-win32](https://armkeil.blob.core.windows.net/developer/Files/downloads/gnu-rm/10.3-2021.10/gcc-arm-none-eabi-10.3-2021.10-win32.zip)

构建工具： [Ninja](https://github.com/ninja-build/ninja/releases/download/v1.11.1/ninja-win.zip)

编辑器：vscode

调试接口连接： openocd（默认dap）

编译器路径配置： ./cmake/arm-none-eabi-gcc.cmake

调试配置：      ./.vscode/Radar_Ctrl.code-workspace

