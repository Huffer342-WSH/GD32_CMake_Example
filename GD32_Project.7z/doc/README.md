# GD32+S3KM111L 制作空调雷达

MCU：GD32F310F8P6

Flash：64KB

SRAM：8KB

## 接口

![Alt text](image.png)
![Alt text](image-2.png)

![Alt text](image-5.png)
![Alt text](image-6.png)

由上图可得该板采用IIC配置接口和SPI数据接口


### IIC配置接口

Pin23 3.3K电阻拉低及低电平，Pin24悬空及高电平，故使用IIC接口配置

![Alt text](image-1.png) 
![Alt text](image-3.png)
![Alt text](image-9.png)

Pin27、Pin27 3.3K电阻拉低均为低电平，故使用IIC从机地址为 7'b00100000(0x20),八位表示0x40

### IIC读写时序

![Alt text](image-4.png)

#### 写入

1. start
2. 发送从机地址 （0x40 | 0x01）
3. 发送需要修改的寄存器地址
4. 发送高八位
5. 发送低八位
6. stop

#### 读取

1. start
2. 发送从机地址 （0x40 & 0xFE）
3. 发送需要修改的寄存器地址
4. restart
5. 发送从机地址 （0x40 | 0x01）
6. 接收高八位
7. 接收低八位
8. stop

### SPI数据接收接口



Pin25悬空，使用SPI通讯，S3主机，GD32从机

![Alt text](image-7.png)
![Alt text](image-8.png)

S3通道0（MOSI0）连接到GD32 SPI0（PA4、5、7 alternate functions 0）

## 寄存器配置

|         | 15  | 14  | 13  | 12  | 11  | 10  | 9   | 8   | 7   | 6   | 5   | 4   | 3   | 2   | 1   | 0   | HEX  |
| ------- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---- |
|         | 15  | 14  | 13  | 12  | 11  | 10  | 9   | 8   | 7   | 6   | 5   | 4   | 3   | 2   | 1   | 0   | HEX  |
| default | 1   | 0   | 0   | 0   | 1   | 1   | 1   | 0   | 0   | 0   | 0   | 0   | 0   | 0   | 1   | 0   | 8E02 |
| 1DFFT   | 1   | 0   | 0   | 0   | 1   | 1   | 0   | 0   | 0   | 0   | 1   | 0   | 0   | 1   | 0   | 0   | 8C24 |



一个chrip 980us 时间，32bit*64/128/256 个数据 
比特率为 2.09/4.18/8.36Mbit/s ,