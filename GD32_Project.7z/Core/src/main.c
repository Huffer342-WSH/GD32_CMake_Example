/*!
    \file    main.c
    \brief   led spark with systick, USART print and key example

    \version 2017-06-06, V1.0.0, firmware for GD32F3x0
    \version 2019-06-01, V2.0.0, firmware for GD32F3x0
    \version 2020-09-30, V2.1.0, firmware for GD32F3x0
    \version 2022-01-06, V2.2.0, firmware for GD32F3x0
*/

/*
    Copyright (c) 2022, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors
       may be used to endorse or promote products derived from this software without
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
#include "string.h"
#include "gd32f3x0.h"
#include "systick.h"
#include "main.h"
#include "log.h"
#include "iic.h"
#include "spi.h"
#include "uart.h"
#include "radar_cfg.h"
#include "radar_data.h"
#include "SEGGER_RTT.h"
#include "SEGGER_RTT_Extended.h"

extern void DMA_Channel1_2_IRQHandler(void);
extern void USART1_IRQHandler(void);
/*!
    \brief      main function
    \param[in]  none
    \param[out] none
    \retval     none
*/

int main(void) {
    systick_config();

    delay_ms(1000);

    Usartx_Init();
    IIC_Init();
    Spi_Init();

    SEGGER_RTT_Init();
    printf("Start\n");
    // RadarCfg_ReadAll();
    // UART_Transmit_DMA(USART1, s, 12);
#if 1 /* RTT测试 */
    {
#if 0 /* 多通道测试 */
        {
            int index;
            index = SEGGER_RTT_AllocUpBuffer("Terminal", upbuffer2, 64,
                                             SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
            index = SEGGER_RTT_AllocDownBuffer("Terminal", downbuffer2, 16,
                                               SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
            do {
                SEGGER_RTT_printf(0, "Here is ch 0");
                // SEGGER_RTT_printf(0, "another buffer index:%d", index);
                delay_ms(100);

                SEGGER_RTT_printf(1, "Here is ch 1\n");
                SEGGER_RTT_TransmitNoLock(1, buf, 24);
                delay_ms(500);
            } while (0);
        }

#endif /* 多通道测试 */
#if 0  /* RTT速率测试 */
        {
            uint32_t time, time_new, bitsNum;
            uint32_t bufsize = 4096;
            uint8_t* buf;
            buf = Get_SpiBufferAddr();
            for (int i = 0; i < bufsize; i++) {
                buf[i] = i % 10 + '0';
            }
            do {
                // delay_ms(500);
                // for (int i = 0; i < bufsize; i++) {
                //     buf[i] = i % 10 + '0';
                // }
                time = Get_Tick();
                // SEGGER_RTT_Write(0, buf, bufsize);
                SEGGER_RTT_TransmitNoLock(0, buf, bufsize);
                time_new = Get_Tick();
                bitsNum = bufsize * 8;
                SEGGER_RTT_printf(0, "\n\n  bitsNum:%lu  tick:%lu \n\n", bitsNum, time_new - time);
                LOG("size:\t%d bits\ntime:\t%d tick\nspeed:\t%2.3f Mhz\n", bitsNum, time_new - time,
                    (float)bitsNum * (float)SystemCoreClock / (float)(time_new - time) / 1000000.f);
            } while (1);
        }

#endif /* RTT速率测试 */
    }
#endif /* RTT测试 */

#if 0 /*串口与系统时钟测试*/
    {
        LOG("%08X %08X", &RCU_CFG0, RCU_AHB_CKSYS_DIV1);
        LOG("%08X %08X", &RCU_CFG0, RCU_APB2_CKAHB_DIV2);
        LOG("%08X %08X", &RCU_CFG0, RCU_APB1_CKAHB_DIV2);
        LOG("%08X %08X", &RCU_CFG0,
            ~(RCU_CFG0_PLLSEL | RCU_CFG0_PLLMF | RCU_CFG0_PLLMF4 | RCU_CFG0_PLLPREDV));
        LOG("%08X %08X", &RCU_CFG1, ~(RCU_CFG1_PLLPRESEL | RCU_CFG1_PLLMF5 | RCU_CFG1_PREDV));
        LOG("%08X %08X", &RCU_CFG0, (RCU_PLLSRC_IRC8M_DIV2 | (RCU_PLL_MUL18 & (~RCU_CFG1_PLLMF5))));
        LOG("%08X %08X", &RCU_CFG1, (RCU_PLL_MUL18 & RCU_CFG1_PLLMF5));
        LOG("%08X %08X", &RCU_CTL0, RCU_CTL0_PLLEN);
        LOG("%08X %08X", &RCU_CFG0, ~RCU_CFG0_SCS);
        LOG("%08X %08X", &RCU_CFG0, RCU_CKSYSSRC_PLL);

        LOG("SystemCoreClock:%lu\n", SystemCoreClock);

        LOG("%08x", DMA_Channel1_2_IRQHandler);
        LOG("%08x", REG32(0x00000068UL));

        unsigned int u32 = 0x12345678;
        unsigned char *a = (unsigned char *)&u32;
        printf("%02X %02X %02X %02X\n", a[0], a[1], a[2], a[3]);

        int i = 0;
        LOG("var i address: 0x%08X", (uint32_t)(&i));

        while (1) {
            delay_ms(1000);
            printf("%d\n", i++);
            /* code */
        }
    }

#endif /*串口与系统时钟测试*/

#if 0 /*IIC接口配置雷达测试*/
    {
        uint16_t buf;
        uint8_t state, reg;
        reg = 0x6D;
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);

        reg = 0x6C;
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);

        reg = 0x72;
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);

        reg = 0x70;
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);
        LOG("尝试修改0x6D为0x99C0");
        reg = 0x6D;
        buf = 0x99C0;
        Radar_Cfg_Write(buf, reg);
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);

        LOG("尝试修改0x6D为0x9900");
        reg = 0x6D;
        buf = 0x99C0;
        (*(radar_reg *)&buf).bit._6 = 0;
        (*(radar_reg *)&buf).bit._7 = 0;

        Radar_Cfg_Write(buf, reg);
        state = Radar_Cfg_Read(&buf, reg);
        LOG("IIC state:%u reg[%x]=%04x", state, reg, buf);
        while (1)
            ;
    }

#endif /*IIC接口配置雷达测试*/

#if 0 /* 串口收发测试 */
    {
        LOG("%08x", USART1_IRQHandler);
        LOG("%08x", REG32(0x000000B0UL));

        char buf[32];
        uint8_t* s;
        uint32_t size;
        UART_Receive_DMA(buf, 32);

        while (1) {
            while (USART1_Get_Rx((uint32_t*)&s, &size)) {
            }
            LOG("size:%d", size);
            UART_Transmit_DMA(USART1, (uint32_t)s, size);
        }
    }

#endif /* 串口收发测试 */
#if 0  /*openocd读取速度测试*/
    OpenOCD_SpeedTest();
#endif /*openocd读取速度测试*/
    char buf[32];
    uint8_t *s;
    uint32_t size;
    UART_Receive_DMA(buf, 32);
    while (1) {
        /* code */
        printf("Input command...\n");
        while (USART1_Get_Rx((uint32_t *)&s, (uint32_t *)&size)) {
        }
        if (!memcmp("1dfft", s, 5)) {
            Get_1DFFT_Data();
        }
    }

    // Get_2DFFT_Peak_Data();
}
