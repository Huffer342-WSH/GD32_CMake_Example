#include "spi.h"
#include "radar_port_cfg.h"

#define SPI_CHx RADAR_SPI_CHx
#define SPI_DMA_CHx RADAR_SPI_DMA_CHx
#define RCU_SPIx RCU_SPI0

static void rcu_config(void) {
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_DMA);
    rcu_periph_clock_enable(RCU_SPIx);
}

static void gpio_config() {
    /* configure SPI_CHx GPIO: SCK/PA5, MISO/PA6, MOSI/PA7 */
    gpio_af_set(GPIOA, GPIO_AF_0, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_7);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_7);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ,
                            GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_7);
}

static void dma_config(void) {
    dma_parameter_struct dma_init_struct;
    dma_struct_para_init(&dma_init_struct);

    /* configure SPI_CHx receive DMA: SPI_DMA_CHx */
    dma_deinit(SPI_DMA_CHx);
    dma_init_struct.periph_addr = (uint32_t)&SPI_DATA(SPI_CHx);
    dma_init_struct.memory_addr = 0;
    dma_init_struct.direction = DMA_PERIPHERAL_TO_MEMORY;
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_16BIT;
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_16BIT;
    dma_init_struct.priority = DMA_PRIORITY_HIGH;
    dma_init_struct.number = 0;
    dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE;
    dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE;
    dma_init(SPI_DMA_CHx, &dma_init_struct);
    /* configure DMA mode */
    dma_circulation_disable(SPI_DMA_CHx);
    dma_memory_to_memory_disable(SPI_DMA_CHx);
}

static void spi_config() {
    spi_parameter_struct spi_init_struct;
    /* deinitilize SPI and the parameters */
    spi_i2s_deinit(SPI_CHx);

    spi_init_struct.device_mode = SPI_SLAVE;
    spi_init_struct.trans_mode = SPI_TRANSMODE_RECEIVEONLY;
    spi_init_struct.frame_size = SPI_FRAMESIZE_16BIT;
    spi_init_struct.nss = SPI_NSS_HARD;
    spi_init_struct.endian = SPI_ENDIAN_MSB;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;
    spi_init_struct.prescale = SPI_PSC_2;

    spi_init(SPI_CHx, &spi_init_struct);
}
void Spi_Init() {
    /* enable peripheral clock */
    rcu_config();
    gpio_config();
    dma_config();
    spi_config();
    nvic_irq_enable(DMA_Channel1_2_IRQn, 1, 2);
}