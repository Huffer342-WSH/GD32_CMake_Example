#include "iic.h"

void I2C0_Gpio_Config() {
    /* connect PB6 to I2C0_SCL */
    gpio_af_set(I2CX_SCL_PORT, GPIO_AF_4, I2CX_SCL_PIN);
    /* connect PB7 to I2C0_SDA */
    gpio_af_set(I2CX_SDA_PORT, GPIO_AF_4, I2CX_SDS_PIN);
    /* configure GPIO pins of I2C0 */
    gpio_mode_set(I2CX_SCL_PORT, GPIO_MODE_AF, GPIO_PUPD_PULLUP, I2CX_SCL_PIN);
    gpio_output_options_set(I2CX_SCL_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, I2CX_SCL_PIN);
    gpio_mode_set(I2CX_SDA_PORT, GPIO_MODE_AF, GPIO_PUPD_PULLUP, I2CX_SDS_PIN);
    gpio_output_options_set(I2CX_SDA_PORT, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, I2CX_SDS_PIN);
}

void I2C0_Config() {
    /* configure I2C clock */
    i2c_clock_config(I2C0, 100000, I2C_DTCY_2);
    /* configure I2C address */
    i2c_mode_addr_config(I2C0, I2C_I2CMODE_ENABLE, I2C_ADDFORMAT_7BITS, 0);
    /* enable I2C0 */
    i2c_enable(I2C0);
    /* enable acknowledge */
    i2c_ack_config(I2C0, I2C_ACK_ENABLE);
}

void IIC_Init() {
    /* enable GPIOB clock */
    rcu_periph_clock_enable(RCU_GPIOA);
    /* enable I2C0 clock */
    rcu_periph_clock_enable(RCU_I2C0);
    /* configure GPIO */
    I2C0_Gpio_Config();
    /* configure I2C */
    I2C0_Config();
}

void i2c_bus_reset(void) {
    i2c_deinit(I2CX);
    /* configure SDA/SCL for GPIO */
    GPIO_BC(I2CX_SCL_PORT) |= I2CX_SCL_PIN;
    GPIO_BC(I2CX_SDA_PORT) |= I2CX_SDS_PIN;
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, I2CX_SCL_PIN | I2CX_SDS_PIN);
    __NOP();
    __NOP();
    __NOP();
    __NOP();
    __NOP();
    GPIO_BOP(I2CX_SCL_PORT) |= I2CX_SCL_PIN;
    __NOP();
    __NOP();
    __NOP();
    __NOP();
    __NOP();
    GPIO_BOP(I2CX_SDA_PORT) |= I2CX_SDS_PIN;
    /* connect I2C_SCL_GPIO_PIN to I2C_SCL */
    /* connect I2C_SDA_GPIO_PIN to I2C_SDA */
    gpio_output_options_set(GPIOB, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, I2CX_SCL_PIN | I2CX_SDS_PIN);
    /* configure the I2CX interface */
    I2C0_Config();
}
