#include "test.h"
#include "log.h"
#include "systick.h"

static char rx_buf[16];
void EXTI0_1_IRQHandler(void);

void OpenOCD_SpeedTest() {
    rcu_periph_clock_enable(RCU_CFGCMP);
    nvic_irq_enable(EXTI0_1_IRQn, 2U, 0U);
    exti_interrupt_flag_clear(EXTI_0);
    exti_interrupt_enable(EXTI_0);
    // LOG("%08x", EXTI0_1_IRQHandler);
    // LOG("%08x", REG32(0x00000054));
    LOG("EXTI_SWIEV:%08x  linex:%08x", &EXTI_SWIEV, EXTI_0);
    LOG("mmw 0x%08x  0x%08x 0", &EXTI_SWIEV, EXTI_0);

    printf("Ready to begin.\n");
    while (1) {
        delay_ms(1000);
        // exti_software_interrupt_enable(EXTI_0);
    }
}

void OpenOCD_SpeedTest_IRQHander() {
    static uint32_t start, end, flag = 0;
    if (RESET != exti_interrupt_flag_get(EXTI_0)) {
        exti_interrupt_flag_clear(EXTI_0);
        if (flag == 0) {
            start = Get_Tick();
        } else {
            end = Get_Tick();
            LOG("tick:%u", end - start);
        }
        flag = !flag;
    }
}
void EXTI0_1_IRQHandler(void) { OpenOCD_SpeedTest_IRQHander(); }
