#include "radar_cfg.h"
#include "iic.h"
#include "gd32f3x0.h"
#include "log.h"

uint8_t Radar_Cfg_Write(uint16_t reg_value, uint8_t reg_addr) {
    uint8_t number_of_byte = 2;
    uint8_t state = I2C_START;
    uint16_t timeout = 0;
    uint8_t i2c_timeout_flag = 0;
    uint8_t *buf = ((uint8_t *)&reg_value) + 1;
    /* enable acknowledge */
    i2c_ack_config(I2CX, I2C_ACK_ENABLE);
    while (!(i2c_timeout_flag)) {
        switch (state) {
            case I2C_START:
                /* i2c master sends start signal only when the bus is idle */
                while (i2c_flag_get(I2CX, I2C_FLAG_I2CBSY) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    i2c_start_on_bus(I2CX);
                    timeout = 0;
                    state = I2C_SEND_ADDRESS;
                } else {
                    i2c_bus_reset();
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c bus is busy in WRITE!\n");
                }
                break;

            case I2C_SEND_ADDRESS:
                /* i2c master sends START signal successfully */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_SBSEND)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    i2c_master_addressing(I2CX, I2C_SLAVE_ADDRESS7, I2C_TRANSMITTER);
                    timeout = 0;
                    state = I2C_CLEAR_ADDRESS_FLAG;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c master sends start signal timeout in WRITE!\n");
                }
                break;

            case I2C_CLEAR_ADDRESS_FLAG:
                /* address flag set means i2c slave sends ACK */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_ADDSEND)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    i2c_flag_clear(I2CX, I2C_FLAG_ADDSEND);
                    timeout = 0;
                    state = I2C_TRANSMIT_DATA;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c master clears address flag timeout in WRITE!\n");
                }
                break;

            case I2C_TRANSMIT_DATA:
                /* wait until the transmit data buffer is empty */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_TBE)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    /* send the EEPROM's internal address to write to : only one byte address */
                    i2c_data_transmit(I2CX, reg_addr);
                    timeout = 0;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c master sends EEPROM's internal address timeout in WRITE!\n");
                }

                /* wait until BTC bit is set */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_BTC)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    timeout = 0;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c master sends data timeout in WRITE!\n");
                }

                while (number_of_byte--) {
                    i2c_data_transmit(I2CX, *buf);

                    /* point to the next byte to be written */
                    buf--;

                    /* wait until BTC bit is set */
                    while ((!i2c_flag_get(I2CX, I2C_FLAG_BTC)) && (timeout < I2C_TIME_OUT)) {
                        timeout++;
                    }

                    if (timeout < I2C_TIME_OUT) {
                        timeout = 0;
                    } else {
                        timeout = 0;
                        state = I2C_START;
                        LOG("i2c master sends data timeout in WRITE!\n");
                    }
                }

                timeout = 0;
                state = I2C_STOP;
                break;

            case I2C_STOP:
                /* send a stop condition to I2C bus */
                i2c_stop_on_bus(I2CX);

                /* i2c master sends STOP signal successfully */
                while ((I2C_CTL0(I2CX) & I2C_CTL0_STOP) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    timeout = 0;
                    state = I2C_END;
                    i2c_timeout_flag = I2C_OK;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    LOG("i2c master sends stop signal timeout in WRITE!\n");
                }
                break;

            default:
                state = I2C_START;
                i2c_timeout_flag = I2C_OK;
                timeout = 0;
                LOG("i2c master sends start signal in WRITE.\n");
                break;
        }
    }

    return I2C_END;
}

uint8_t Radar_Cfg_Read(uint16_t *p_reg_value, uint8_t reg_addr) {
    i2c_process_enum state = I2C_START;
    uint8_t read_cycle = 0;
    uint16_t timeout = 0;
    uint8_t i2c_timeout_flag = 0;
    uint8_t number_of_byte = 2;
    uint8_t *buf = ((uint8_t *)p_reg_value) + 1;
    while (!(i2c_timeout_flag)) {
        switch (state) {
            case I2C_START:
                if (RESET == read_cycle) {
                    /* i2c master sends start signal only when the bus is idle */
                    while (i2c_flag_get(I2CX, I2C_FLAG_I2CBSY) && (timeout < I2C_TIME_OUT)) {
                        timeout++;
                    }

                    if (timeout < I2C_TIME_OUT) {
                        /* whether to send ACK or not for the next byte */
                        if (2 == number_of_byte) {
                            i2c_ackpos_config(I2CX, I2C_ACKPOS_NEXT);
                        }
                    } else {
                        i2c_bus_reset();
                        timeout = 0;
                        state = I2C_START;
                        LOG("i2c bus is busy in READ!\n");
                    }
                }

                /* send the start signal */
                i2c_start_on_bus(I2CX);
                timeout = 0;
                state = I2C_SEND_ADDRESS;
                break;

            case I2C_SEND_ADDRESS:
                /* i2c master sends START signal successfully */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_SBSEND)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    if (RESET == read_cycle) {
                        i2c_master_addressing(I2CX, I2C_SLAVE_ADDRESS7, I2C_TRANSMITTER);
                        state = I2C_CLEAR_ADDRESS_FLAG;
                    } else {
                        i2c_master_addressing(I2CX, I2C_SLAVE_ADDRESS7, I2C_RECEIVER);
                        if (number_of_byte < 3) {
                            /* disable acknowledge */
                            i2c_ack_config(I2CX, I2C_ACK_DISABLE);
                        } else {
                            /* enable acknowledge */
                            i2c_ack_config(I2CX, I2C_ACK_ENABLE);
                        }
                        state = I2C_CLEAR_ADDRESS_FLAG;
                    }
                    timeout = 0;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    read_cycle = 0;
                    LOG("i2c master sends start signal timeout in READ!\n");
                }
                break;

            case I2C_CLEAR_ADDRESS_FLAG:
                /* address flag set means i2c slave sends ACK */
                while ((!i2c_flag_get(I2CX, I2C_FLAG_ADDSEND)) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    i2c_flag_clear(I2CX, I2C_FLAG_ADDSEND);
                    if ((SET == read_cycle) && (1 == number_of_byte)) {
                        /* send a stop condition to I2C bus */
                        i2c_stop_on_bus(I2CX);
                    }

                    timeout = 0;
                    state = I2C_TRANSMIT_DATA;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    read_cycle = 0;
                    LOG("i2c master clears address flag timeout in READ!\n");
                }
                break;

            case I2C_TRANSMIT_DATA:
                if (RESET == read_cycle) {
                    /* wait until the transmit data buffer is empty */
                    while ((!i2c_flag_get(I2CX, I2C_FLAG_TBE)) && (timeout < I2C_TIME_OUT)) {
                        timeout++;
                    }

                    if (timeout < I2C_TIME_OUT) {
                        /* send the EEPROM's internal address to write to : only one byte address */
                        i2c_data_transmit(I2CX, reg_addr);
                        timeout = 0;
                    } else {
                        timeout = 0;
                        state = I2C_START;
                        read_cycle = 0;
                        LOG("i2c master wait data buffer is empty timeout in READ!\n");
                    }

                    /* wait until BTC bit is set */
                    while ((!i2c_flag_get(I2CX, I2C_FLAG_BTC)) && (timeout < I2C_TIME_OUT)) {
                        timeout++;
                    }

                    if (timeout < I2C_TIME_OUT) {
                        timeout = 0;
                        state = I2C_START;
                        read_cycle++;
                    } else {
                        timeout = 0;
                        state = I2C_START;
                        read_cycle = 0;
                        LOG("i2c master sends EEPROM's internal address timeout in READ!\n");
                    }
                } else {
                    while (number_of_byte) {
                        timeout++;

                        if (3 == number_of_byte) {
                            /* wait until BTC bit is set */
                            while (!i2c_flag_get(I2CX, I2C_FLAG_BTC))
                                ;
                            /* disable acknowledge */
                            i2c_ack_config(I2CX, I2C_ACK_DISABLE);
                        }

                        if (2 == number_of_byte) {
                            /* wait until BTC bit is set */
                            while (!i2c_flag_get(I2CX, I2C_FLAG_BTC))
                                ;
                            /* send a stop condition to I2C bus */
                            i2c_stop_on_bus(I2CX);
                        }

                        /* wait until RBNE bit is set */
                        if (i2c_flag_get(I2CX, I2C_FLAG_RBNE)) {
                            /* read a byte from the EEPROM */
                            *buf = i2c_data_receive(I2CX);

                            /* point to the next location where the byte read will be saved */
                            buf--;

                            /* decrement the read bytes counter */
                            number_of_byte--;
                            timeout = 0;
                        }

                        if (timeout > I2C_TIME_OUT) {
                            timeout = 0;
                            state = I2C_START;
                            read_cycle = 0;
                            LOG("i2c master sends data timeout in READ!\n");
                        }
                    }

                    timeout = 0;
                    state = I2C_STOP;
                }
                break;

            case I2C_STOP:
                /* i2c master sends STOP signal successfully */
                while ((I2C_CTL0(I2CX) & I2C_CTL0_STOP) && (timeout < I2C_TIME_OUT)) {
                    timeout++;
                }

                if (timeout < I2C_TIME_OUT) {
                    timeout = 0;
                    state = I2C_END;
                    i2c_timeout_flag = I2C_OK;
                } else {
                    timeout = 0;
                    state = I2C_START;
                    read_cycle = 0;
                    LOG("i2c master sends stop signal timeout in READ!\n");
                }
                break;

            default:
                state = I2C_START;
                read_cycle = 0;
                i2c_timeout_flag = I2C_OK;
                timeout = 0;
                LOG("i2c master sends start signal in READ.\n");
                break;
        }
    }

    return I2C_END;
}

void RadarCfg_ReadAll() {
    uint16_t regval;
    uint8_t state;
    for (uint8_t i = 0; i <= 0x72; i++) {
        state = Radar_Cfg_Read(&regval, i);
        printf("addr: 0x%02X\tval: 0x%04X\n", i, regval);
    }
}