/*
2DFFT data num * chirp num = 1024

*/
#include "radar_data.h"
#include "radar_cfg.h"
#include "spi.h"
#include "log.h"
#include "systick.h"
#include "uart.h"
#include "SEGGER_RTT.h"
#include "SEGGER_RTT_Extended.h"
#define DMA_BUF_SIZE 5752
/*全局变量*/
uint16_t dma_int_count;

const static uint8_t BufferIndex = 0;
SEGGER_RTT_BUFFER_UP* pUpBuffer;

static uint8_t spi_rx_buf[DMA_BUF_SIZE] __attribute__((aligned(4)));
// static uint16_t logsave[32][2];
static uint32_t ticklog[128];
static uint8_t IRQ_dma_ch1_int_flag = 0;
static uint8_t IRQ_dma_ch1_overflow = 0;
static uint32_t IRQ_block_size, IRQ_block_num, IRQ_block_index, IRQ_buffer_size, IRQ_dma_size;
static mode;
/**
 * @brief
 * Head ： 32'b1010_1010_0011_xxxx_xxxx_x00x_xxxx_xxxx
 *             A    A    3
 */
void Get_1DFFT_Data() {
    uint16_t cfg_fft_tx_max;
    uint16_t cfg_fft_size;
    uint16_t cfg_fft_chirp_num;

    uint16_t reg_value;
    uint16_t reg_out;
    uint16_t chrip_size;

    uint16_t chrip_num_per_int;

    /*---------- 配置雷达 ----------*/
    LOG("========== CONFIGURE THE RADAR ================");

    /*关闭雷达数据输出*/
    Radar_Cfg_Write(0x0020, 0x01);

    // for (uint8_t i = 0x45; i <= 0x4c; i++) {
    //     Radar_Cfg_Read(&reg_value, i);
    //     LOG("REG[%02X]: %-6d", i, reg_value);
    // }
    /* 设置chrip时长*/
    // 00
    Radar_Cfg_Write(Set_Bits(0, 0, 11, 0xfff), 0x45);   // 4096
    Radar_Cfg_Write(Set_Bits(0, 0, 15, 0xffff), 0x46);  // 51200

    // 01
    Radar_Cfg_Write(Set_Bits(0, 0, 11, 0xfff), 0x47);   // 0
    Radar_Cfg_Write(Set_Bits(0, 0, 15, 0xffff), 0x48);  // 10000

    // 10
    Radar_Cfg_Write(Set_Bits(0, 0, 11, 0xfff), 0x49);   // 0
    Radar_Cfg_Write(Set_Bits(0, 0, 15, 0xffff), 0x4a);  // 10000

    // 11
    Radar_Cfg_Write(Set_Bits(0, 0, 11, 0xfff), 0x4b);   // 0
    Radar_Cfg_Write(Set_Bits(0, 0, 15, 0xffff), 0x4c);  // 8800
    for (uint8_t i = 0x45; i <= 0x4c; i++) {
        Radar_Cfg_Read(&reg_value, i);
        LOG("REG[%02X]: %-6d", i, reg_value);
    }

    /*配置两个frame之间的时间*/
    // 0x51   0x0029  ; //
    // 0x52   0x8100  ; //
    Radar_Cfg_Write(Set_Bits(0, 0, 13, 0x3ff), 0x51);
    Radar_Cfg_Write(Set_Bits(0, 0, 15, 0xffff), 0x52);

    /*设置1DFFT点数，00=64 01=128 10=256*/
    Radar_Cfg_Read(&reg_value, 0x09);
    Radar_Cfg_Write(Set_Bits(reg_value, 10, 11, 0x00), 0x09);
    Radar_Cfg_Read(&reg_value, 0x09);
    cfg_fft_size = 64 << Get_Bits(reg_value, 10, 11);

    // 设置DMA发送长度
    Radar_Cfg_Read(&reg_value, 0x05);
    Radar_Cfg_Write(64, 0x05);
    Radar_Cfg_Read(&reg_value, 0x05);
    cfg_fft_tx_max = Get_Bits(reg_value, 0, 8);

    // 设置每个frame的chrip数量
    Radar_Cfg_Read(&reg_value, 0x44);
    Radar_Cfg_Write(Set_Bits(reg_value, 0, 9, 16), 0x44);
    Radar_Cfg_Read(&reg_value, 0x44);
    cfg_fft_chirp_num = Get_Bits(reg_value, 0, 9);

    LOG("1DFFT 长度：%d", cfg_fft_size);
    LOG("DMA 发送长度：%d", cfg_fft_tx_max);
    LOG("单 frame包含的chirp数量:%d", cfg_fft_chirp_num);

    /*---------- 计算相关参数 ----------*/

    chrip_size = (cfg_fft_tx_max + 2) * 4;
    // chrip_num_per_int = DMA_BUF_SIZE / 2 / chrip_size;
    chrip_num_per_int = 1;

    IRQ_dma_size = chrip_num_per_int * chrip_size;  // 一次DMA接收的byte数
    IRQ_block_size = IRQ_dma_size / 2;              // 保留的byte数
    IRQ_block_num = (DMA_BUF_SIZE - IRQ_dma_size + IRQ_block_size) / IRQ_block_size;  //
    IRQ_buffer_size = IRQ_block_size * IRQ_block_num;
    IRQ_block_index = 0;
    mode = 0;
    /*---------- 初始化RTT Buffer ----------*/
    SEGGER_RTT_ConfigUpBuffer(BufferIndex, "Terminal", spi_rx_buf, IRQ_buffer_size,
                              SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
    pUpBuffer = &_SEGGER_RTT.aUp[BufferIndex];

    /*---------- 配置单片机DMA ----------*/

    /*关闭SPI与 DMA*/
    dma_channel_disable(DMA_CH1);
    spi_disable(SPI0);

    /*配置DMA 目标地址*/
    dma_memory_address_config(DMA_CH1, (uint32_t)spi_rx_buf);
    /*配置传输大小*/
    dma_memory_width_config(DMA_CH1, DMA_MEMORY_WIDTH_16BIT);
    /*配置DMA传输数量*/
    dma_transfer_number_config(DMA_CH1, IRQ_dma_size / 2);
    /*配置传输完成中断*/
    dma_interrupt_enable(DMA_CH1, DMA_INT_FTF);

    /*打开DMA通道*/
    spi_enable(SPI0);
    dma_channel_enable(DMA_CH1);
    spi_dma_enable(SPI0, SPI_DMA_RECEIVE);
    LOG("DMA_CNT: %lu", dma_transfer_number_get(DMA_CH1));

    dma_int_count = 0;
    static uint32_t time, time_new;
    IRQ_dma_ch1_overflow = 0;
    /*---------- 打开雷达 ----------*/
    LOG("========== ONE FRAMEE BEGIN ================");

    time = Get_Tick();

    Radar_Cfg_Write(0x8824, 0x01);

    while (!IRQ_dma_ch1_overflow &&
           dma_int_count * chrip_num_per_int < cfg_fft_chirp_num /*cfg_fft_chirp_num * 2*/) {
        if (!IRQ_dma_ch1_int_flag) continue;

        // UART_Transmit_DMA(USART1, (uint32_t)(&(spi_rx_buf[(IRQ_block_index - 1) *
        // IRQ_block_size])),
        //                   IRQ_block_size);
        // SEGGER_RTT_TransmitNoLock(0, (void*)address_prev, IRQ_block_size / 50);
        // SEGGER_RTT_Write(0, (void*)address_prev, IRQ_block_size);
        uint32_t i = IRQ_block_index;
        if (i == 0) {
            i = IRQ_block_size * (IRQ_block_num - 1);
        } else {
            i = IRQ_block_size * (i - 1);
        }

        // printf("%02x %02x %02x %02x\n", spi_rx_buf[i + 1], spi_rx_buf[i], spi_rx_buf[i + 3],
        //        spi_rx_buf[i + 2]);
        printf("%u\n", (spi_rx_buf[i + 3] >> 3));
        IRQ_dma_ch1_int_flag = 0;
    }
    spi_disable(SPI0);
    if (dma_int_count * chrip_num_per_int < cfg_fft_chirp_num) {
        LOG("DMA_CH1 overflow");
    }
    // while (pUpBuffer->RdOff != pUpBuffer->WrOff)
    //     ;

    time_new = Get_Tick();
    uint32_t bitsNum = (uint32_t)dma_int_count * (uint32_t)IRQ_block_size * 8UL;
    LOG("size:\t%d bits\ntime:\t%d tick\nspeed:\t%2.3f Mhz\n", bitsNum, time_new - time,
        (float)bitsNum * (float)SystemCoreClock / (float)(time_new - time) / 1000000.f);
    // for (int i = 0; i < dma_int_count; i++) {
    //     LOG("[ %-2d ]: %u ", i, ticklog[i]);
    // }
    LOG("========== ONE FRAMEE END ================");
}

void Get_2DFFT_Peak_Data() {
    /*关闭雷达数据输出*/
    spi_disable(SPI0);
    Radar_Cfg_Write(0x0020, 0x01);
    spi_i2s_data_frame_format_config(SPI0, SPI_FRAMESIZE_8BIT);
    spi_enable(SPI0);

    Radar_Cfg_Write(0x8830, 0x01);
    uint32_t index = 0;
    while (index < 160) {
        if (RESET == spi_i2s_flag_get(SPI0, SPI_FLAG_RBNE)) {
            continue;
        }
        spi_rx_buf[index] = ((uint16_t)SPI_DATA(SPI0));
        index++;
        // LOG("%d", index);
    }
    for (int i = 0; i < 160; i += 4) {
        printf("%d:\t%02X %02X %02X %02X\n", i >> 2, spi_rx_buf[i], spi_rx_buf[i + 1],
               spi_rx_buf[i + 2], spi_rx_buf[i + 3]);
        // printf("%d:\t%02d %02d\n", i >> 2, spi_rx_buf[i], spi_rx_buf[i + 1]);
    }
}
uint8_t* Get_SpiBufferAddr() { return spi_rx_buf; }

void IRQHandler_1Ffft() {
    uint32_t Rdoff;
    static uint32_t time, time_new;
    if (SET == dma_interrupt_flag_get(DMA_CH1, DMA_INT_FLAG_FTF)) {
        dma_interrupt_flag_clear(DMA_CH1, DMA_INT_FLAG_G);
        IRQ_dma_ch1_int_flag = 1;
        dma_int_count++;

        /*---------- 计算参数 ----------*/
        /* 获取下一个block index */
        if (++IRQ_block_index == IRQ_block_num) {
            IRQ_block_index = 0;
        }

        /*---------- 判断溢出 ----------*/
#if 1
        // 当Rdoff处于下一个将要被写入SPI接收数据的block内时，认为已经溢出
        Rdoff = pUpBuffer->RdOff;
        // printf("Rdoff:%d Wroff%d\n", Rdoff, pUpBuffer->WrOff);
        if (Rdoff >= IRQ_block_index * IRQ_block_size &&
            Rdoff < (IRQ_block_index + 1) * IRQ_block_size) {
            IRQ_dma_ch1_overflow = 1;
            spi_disable(SPI0);
            LOG("Rdoff:%d\nIRQ_block_index:%d\nnextWroff:%d", Rdoff, IRQ_block_index,
                IRQ_block_index * IRQ_block_size);
            // for (int i = 0; i < dma_int_count; i++) {
            //     LOG("Rd:%d Wr:%d", logsave[i][0], logsave[i][1] * IRQ_block_size);
            // }

            return;
        }

        /*---------- 更新Buffer ----------*/
        SEGGER_RTT_LOCK();
        RTT__DMB();
        pUpBuffer->WrOff = IRQ_block_index * IRQ_block_size;
        SEGGER_RTT_UNLOCK();
#endif
        /*---------- 重新配置DMA ----------*/
        dma_channel_disable(DMA_CH1);
        dma_memory_address_config(
            DMA_CH1,
            (uint32_t)(&(spi_rx_buf[IRQ_block_index * IRQ_block_size])));  // 设置地址
        dma_channel_enable(DMA_CH1);
        // time_new = Get_Tick();
        // ticklog[dma_int_count] = time_new - time;
        // time = time_new;
        // logsave[dma_int_count][0] = Rdoff;
        // logsave[dma_int_count][1] = IRQ_block_index;
    } else if (SET == dma_interrupt_flag_get(DMA_CH1, DMA_INT_FLAG_ERR)) {
        LOG("DMA_CH1 ERROR");
        while (1) {
            /* code */
        }
    }
}
// 中断函数
void DMA_Channel1_2_IRQHandler(void) {
    if (mode == 0) {
        IRQHandler_1Ffft();
    }
}