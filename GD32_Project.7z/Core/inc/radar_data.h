#ifndef _RADAR_H_
#define _RADAR_H_
#include "gd32f3x0.h"
extern uint16_t rfft_chirp_cnt;

void Get_1DFFT_Data();
uint8_t* Get_SpiBufferAddr();
#endif /*_RADAR_H_*/