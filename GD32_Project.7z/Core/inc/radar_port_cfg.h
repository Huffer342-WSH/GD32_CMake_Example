#ifndef _RADAR_PORT_CFG_H_
#define _RADAR_PORT_CFG_H_

#include "gd32f3x0.h"

/* 配置端口 */
#define RADAR_IIC_SLAVE_ADDRESS 0x40U
#define RADAR_IIC_CHx I2C0
#define RADAR_IIC_SCL_PORT GPIOA
#define RADAR_IIC_SDA_PORT GPIOA
#define RADAR_IIC_SCL_PIN GPIO_PIN_9
#define RADAR_IIC_SDS_PIN GPIO_PIN_10

/* 数据传输端口 */
#define RADAR_SPI_CHx SPI0
#define RADAR_SPI_DMA_CHx DMA_CH1

#endif /* _RADAR_PORT_CFG_H_ */