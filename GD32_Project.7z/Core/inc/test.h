#ifndef _TEST_H_
#define _TEST_H_
#include "gd32f3x0.h"
void OpenOCD_SpeedTest();
#endif /* _TEST_H_ */