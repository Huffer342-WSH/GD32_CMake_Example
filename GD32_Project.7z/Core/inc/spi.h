/*
SPI0
PA4 NSS AF1
PA5 SCK AF1
PA7 MOSI AF1
*/
#ifndef _SPI_H_
#define _SPI_H_

#include "gd32f3x0.h"

void Spi_Init();
#endif